<?php

namespace Mautic\ChannelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class MauticChannelBundle.
 */
class MauticChannelBundle extends Bundle
{
}
