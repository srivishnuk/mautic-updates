<?php

namespace Mautic\ConfigBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class MauticConfigBundle.
 */
class MauticConfigBundle extends Bundle
{
}
