<?php

namespace Mautic\ConfigBundle\Exception;

class BadFormConfigException extends \Exception
{
}
