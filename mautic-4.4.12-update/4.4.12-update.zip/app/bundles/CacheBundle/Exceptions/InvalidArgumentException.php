<?php

declare(strict_types=1);

namespace Mautic\CacheBundle\Exceptions;

class InvalidArgumentException extends \Symfony\Component\Cache\Exception\InvalidArgumentException
{
}
