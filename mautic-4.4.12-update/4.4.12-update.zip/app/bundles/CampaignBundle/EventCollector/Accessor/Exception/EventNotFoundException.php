<?php

namespace Mautic\CampaignBundle\EventCollector\Accessor\Exception;

class EventNotFoundException extends \InvalidArgumentException
{
}
