<?php

namespace Mautic\CampaignBundle\EventCollector\Accessor\Exception;

class TypeNotFoundException extends \InvalidArgumentException
{
}
