<?php

namespace Mautic\CampaignBundle\Executioner\Exception;

class CampaignNotExecutableException extends \Exception
{
}
