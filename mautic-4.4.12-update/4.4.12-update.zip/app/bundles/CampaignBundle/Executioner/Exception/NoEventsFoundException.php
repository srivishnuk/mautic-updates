<?php

namespace Mautic\CampaignBundle\Executioner\Exception;

class NoEventsFoundException extends \Exception
{
}
