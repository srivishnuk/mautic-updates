<?php

namespace Mautic\CampaignBundle\Executioner\Exception;

class ConditionFailedException extends \Exception
{
}
