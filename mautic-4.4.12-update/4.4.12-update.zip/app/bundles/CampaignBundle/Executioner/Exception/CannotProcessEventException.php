<?php

namespace Mautic\CampaignBundle\Executioner\Exception;

class CannotProcessEventException extends \Exception
{
}
