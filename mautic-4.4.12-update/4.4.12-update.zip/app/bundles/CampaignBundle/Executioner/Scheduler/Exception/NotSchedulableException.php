<?php

namespace Mautic\CampaignBundle\Executioner\Scheduler\Exception;

class NotSchedulableException extends \Exception
{
}
