<?php

namespace Mautic\CampaignBundle\Executioner\Scheduler\Exception;

class NotTimeYetException extends \Exception
{
}
