<?php

namespace Mautic\CampaignBundle\Membership\Exception;

class ContactAlreadyRemovedFromCampaignException extends \Exception
{
}
