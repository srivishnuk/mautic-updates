<?php

namespace Mautic\CampaignBundle\Entity;

use Mautic\CoreBundle\Entity\CommonRepository;

/**
 * LeadEventLogRepository.
 */
class FailedLeadEventLogRepository extends CommonRepository
{
}
