<?php

echo "<hr />\n";
echo $view['form']->row($form);
