<?php

namespace Mautic\CampaignBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class MauticCampaignBundle.
 */
class MauticCampaignBundle extends Bundle
{
}
