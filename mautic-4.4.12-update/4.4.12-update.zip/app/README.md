# Mautic Core-lib repo

## This is a mirror repository of the /app folder of Mautic, and is managed centrally in https://github.com/mautic/mautic/blob/head/app.  This is a read-only mirror repository.

**📣 Please make PRs and issues against the [mautic/mautic](https://github.com/mautic/mautic) repository, not here!**
